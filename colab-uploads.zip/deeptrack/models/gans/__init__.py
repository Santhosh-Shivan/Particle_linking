from .cgan import *
from .cyclegan import *
from .gan import *
from .pcgan import *